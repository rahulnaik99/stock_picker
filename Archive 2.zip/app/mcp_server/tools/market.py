"""Market data: candles and the option chain, both from FYERS v3 (official `fyers-apiv3` SDK).

FYERS is the SINGLE source of market data. If FYERS is unreachable or the token is invalid, the tool returns an
error and the dependent agent becomes unavailable — there is deliberately NO fallback provider, because FYERS is
the reliable source and a silent substitute would be misleading.
"""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timedelta
from typing import Any

import pandas as pd

from app.mcp_server.tools.common import (IST, SourceError, clean_symbol, error, fyers_symbol, is_market_open, now_ist,
                                         ok, parse_as_of, unavailable)
from app.service.logger import get_logger
from app.service.settings import get_settings
from app.store.db import connect, kv_get, kv_set, mark_refreshed, refreshed_today

log = get_logger(__name__)
# FYERS: daily history <= 366 days per call, intraday <= 100 days per call.
_throttle_lock = threading.Lock()
_last_call = 0.0

# ── In-process candle cache ──────────────────────────────────────────────────
# WHY: a single scoring run fires up to 8 technical agents concurrently, each calling
# fetch_candles() for the SAME symbol/resolution. Without a cache they all hit FYERS at
# once → rate-limit errors (that is why `get_technical_indicators` was returning "error"
# while a slightly later `get_demand_supply_zones` succeeded).
# POLICY:
#   • market CLOSED  → candles don't change, cache for the whole calendar day.
#   • market LIVE    → cache for a short TTL so agents in one run share a fetch,
#                      but a fresh run a minute later still re-pulls live prices.
#   • historical as_of (back-test) → cache for the whole day (immutable).
_candle_cache: dict[tuple, tuple[float, "pd.DataFrame", str]] = {}
_candle_lock = threading.Lock()
_LIVE_TTL_SECONDS = 90.0


def _candle_ttl(as_of: str | None) -> float:
    """How long a cached candle set stays valid, in seconds."""
    asof_dt = parse_as_of(as_of)
    # Historical / back-test reads are immutable → cache the whole day.
    if asof_dt.date() < now_ist().date():
        return 86_400.0
    # Live today: short TTL while market open, full day once it has closed.
    return _LIVE_TTL_SECONDS if is_market_open() else 86_400.0


def _throttle(min_interval: float = 0.25) -> None:
    """FYERS allows ~5 requests/second; keep a gap between calls (the MCP server is one process)."""
    global _last_call
    with _throttle_lock:
        wait = _last_call + min_interval - time.monotonic()
        if wait > 0:
            time.sleep(wait)
        _last_call = time.monotonic()


_RES = {"D": ("D", 366), "60": ("60", 100), "15": ("15", 100)}


# ------------------------------------------------------------------ candles
def _fyers_client():
    """Official FYERS v3 SDK client (lazy import: the package is only needed when FYERS is actually called)."""
    s = get_settings()
    if not (s.fyers_app_id and s.fyers_access_token):
        raise SourceError("FYERS_APP_ID / FYERS_ACCESS_TOKEN not set")
    try:
        from fyers_apiv3 import fyersModel
    except ImportError as exc:
        raise SourceError("fyers-apiv3 not installed (pip install fyers-apiv3)") from exc
    return fyersModel.FyersModel(client_id=s.fyers_app_id, token=s.fyers_access_token, is_async=False, log_path="")


def _fyers_candles(symbol: str, resolution: str, start: datetime, end: datetime) -> pd.DataFrame:
    fy = _fyers_client()
    res, max_days = _RES[resolution]
    rows: list[list[float]] = []
    cursor = start.date()
    while cursor <= end.date():
        chunk_end = min(end.date(), cursor + timedelta(days=max_days - 1))
        _throttle()
        payload = fy.history(data={"symbol": fyers_symbol(symbol), "resolution": res, "date_format": "1",
                                   "range_from": cursor.isoformat(), "range_to": chunk_end.isoformat(), "cont_flag": "1"}) or {}
        status = payload.get("s")
        if status == "no_data":
            pass
        elif status != "ok":
            raise SourceError(f"FYERS history {clean_symbol(symbol)} {res}: {payload.get('message') or payload.get('code') or payload}. "
                              "FYERS is the only market-data source (no fallback); check the token with: python -m scripts.fyers_login")
        rows.extend(payload.get("candles") or [])
        cursor = chunk_end + timedelta(days=1)
    if not rows:
        return pd.DataFrame(columns=["time", "open", "high", "low", "close", "volume"])
    df = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close", "volume"])
    df["time"] = pd.to_datetime(df["ts"], unit="s", utc=True).dt.tz_convert(IST)
    return df.drop(columns="ts").drop_duplicates("time").sort_values("time").reset_index(drop=True)


def fetch_candles(symbol: str, resolution: str, days: int, as_of: str | None = None) -> tuple[pd.DataFrame, str]:
    """Return (candles, 'fyers'). Drops the still-forming bar. FYERS is the SINGLE source of market data: if it is
    unreachable or the token is invalid we ABORT (raise) rather than substitute a less reliable provider.

    Cached per (symbol, resolution, days, as_of-date): when the market is closed the same candles are reused all
    day; when live they are shared for a short TTL so concurrent agents don't each hammer FYERS (which was causing
    rate-limit 'error' results on get_technical_indicators)."""
    sym = clean_symbol(symbol)
    asof_dt = parse_as_of(as_of)
    key = (sym, resolution, days, asof_dt.date().isoformat())
    ttl = _candle_ttl(as_of)
    now_mono = time.monotonic()

    with _candle_lock:
        hit = _candle_cache.get(key)
        if hit is not None and (now_mono - hit[0]) < ttl:
            return hit[1].copy(), hit[2]

    df, provider = _fetch_candles_uncached(symbol, resolution, days, as_of)

    with _candle_lock:
        _candle_cache[key] = (now_mono, df.copy(), provider)
        # Bound memory: keep only the most recent ~200 cache entries
        if len(_candle_cache) > 200:
            oldest = sorted(_candle_cache.items(), key=lambda kv: kv[1][0])[:50]
            for k, _ in oldest:
                _candle_cache.pop(k, None)
    return df, provider


def _fetch_candles_uncached(symbol: str, resolution: str, days: int, as_of: str | None = None) -> tuple[pd.DataFrame, str]:
    end = parse_as_of(as_of)
    start = end - timedelta(days=days)
    provider = "fyers"
    df = _fyers_candles(symbol, resolution, start, end)
    if df.empty:
        return df, provider
    df = df[df["time"] <= end]
    # Closed candles only: drop today's daily bar before the close; drop an intraday bar that has not finished.
    now = now_ist()
    if resolution == "D":
        if not df.empty and df["time"].iloc[-1].date() == now.date() and now.hour * 60 + now.minute < 15 * 60 + 45:
            df = df.iloc[:-1]
    else:
        minutes = int(resolution)
        if not df.empty and df["time"].iloc[-1] + timedelta(minutes=minutes) > now:
            df = df.iloc[:-1]
    return df.reset_index(drop=True), provider


def get_candles(symbol: str, timeframe: str = "D", days: int = 120, as_of: str | None = None) -> dict[str, Any]:
    """Closed OHLCV candles (Asia/Kolkata). timeframe: D, 60 or 15. Provider is named in the result."""
    src = "fyers/yfinance"
    try:
        if timeframe not in _RES:
            return error(src, f"timeframe must be one of {list(_RES)}")
        df, provider = fetch_candles(symbol, timeframe, days, as_of)
        if df.empty:
            return unavailable(provider, f"no candles for {clean_symbol(symbol)}")
        data = [{"t": r.time.isoformat(), "o": r.open, "h": r.high, "l": r.low, "c": r.close, "v": r.volume} for r in df.itertuples()]
        return ok(provider, data, symbol=clean_symbol(symbol), timeframe=timeframe, count=len(data))
    except Exception as exc:  # noqa: BLE001 - envelope instead of crash
        return error(src, exc)


# ------------------------------------------------------------------ option chain
def _save_snapshot(symbol: str, row: dict[str, Any]) -> None:
    """One row per capture in SQLite (table oi_snapshots)."""
    with connect() as con:
        con.execute("INSERT OR REPLACE INTO oi_snapshots VALUES (?,?,?,?,?,?,?,?,?)",
                    (clean_symbol(symbol), row["captured_at"], row["call_oi"], row["put_oi"], row.get("pcr"), row.get("ltp"),
                     json.dumps(row.get("support")), json.dumps(row.get("resistance")), row.get("max_pain")))


def _window_changes(symbol: str, call_oi: float, put_oi: float, as_of: datetime) -> dict[str, Any]:
    """Weekly/monthly OI change from our own saved snapshots (the broker gives only day-on-day)."""
    with connect() as con:
        df = pd.DataFrame([dict(r) for r in con.execute("SELECT captured_at, call_oi, put_oi FROM oi_snapshots WHERE symbol=? ORDER BY captured_at",
                                                        (clean_symbol(symbol),))])
    if df.empty:
        return {}
    df["captured_at"] = pd.to_datetime(df["captured_at"], utc=True)
    out: dict[str, Any] = {}
    for label, days in (("1w", 7), ("1m", 30)):
        cutoff = pd.Timestamp(as_of).tz_convert("UTC") - pd.Timedelta(days=days)
        old = df[df["captured_at"] <= cutoff]
        if old.empty:
            out[label] = "insufficient_history"
            continue
        r = old.iloc[-1]
        out[label] = {"from": str(r["captured_at"]), "call_oi_change": call_oi - float(r["call_oi"]), "put_oi_change": put_oi - float(r["put_oi"])}
    return out


def derive_levels(calls: list[dict[str, Any]], puts: list[dict[str, Any]], spot: float | None) -> dict[str, Any]:
    """Support / resistance from open interest. Resistance = highest call-OI strikes at or above spot, support = highest
    put-OI strikes at or below spot (strongest first). Max pain = strike where option writers' total payout is smallest
    (approximate: only the fetched strikes are used). OI levels are context: heavy OI can also be hedging."""
    oi = lambda r: float(r.get("oi") or 0)  # noqa: E731
    strike = lambda r: float(r.get("strike_price") or 0)  # noqa: E731
    up = [c for c in calls if spot is None or strike(c) >= spot] or calls
    dn = [p for p in puts if spot is None or strike(p) <= spot] or puts
    fmt = lambda r: {"strike": strike(r), "oi": oi(r), "oi_change": r.get("oich")}  # noqa: E731
    res = [fmt(r) for r in sorted(up, key=oi, reverse=True)[:3] if oi(r) > 0]
    sup = [fmt(r) for r in sorted(dn, key=oi, reverse=True)[:3] if oi(r) > 0]
    strikes = sorted({strike(r) for r in calls + puts})
    pain = {k: sum(max(0.0, k - strike(c)) * oi(c) for c in calls) + sum(max(0.0, strike(p) - k) * oi(p) for p in puts) for k in strikes}
    return {"resistance": res, "support": sup, "max_pain_approx": min(pain, key=pain.get) if pain else None,
            "basis": "open interest, nearest expiry, fetched strikes only"}


def summarize_chain(payload: dict[str, Any], as_of: datetime) -> dict[str, Any]:
    """Pure function: FYERS options-chain-v3 payload -> compact summary. (Unit-tested with a fixture.)"""
    data = payload.get("data") or {}
    chain = data.get("optionsChain") or []
    under = next((c for c in chain if not c.get("option_type")), None)
    calls = [c for c in chain if c.get("option_type") == "CE"]
    puts = [c for c in chain if c.get("option_type") == "PE"]
    if not calls and not puts:
        raise SourceError("empty option chain")
    call_oi = sum(float(c.get("oi") or 0) for c in calls)
    put_oi = sum(float(c.get("oi") or 0) for c in puts)

    def top(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        best = sorted(rows, key=lambda r: float(r.get("oi") or 0), reverse=True)[:3]
        return [{"strike": r.get("strike_price"), "oi": r.get("oi"), "oi_change": r.get("oich"), "volume": r.get("volume")} for r in best]

    return {
        "underlying_ltp": (under or {}).get("ltp"),
        "underlying_change_pct": (under or {}).get("ltpchp"),
        "expiries": [e.get("date") for e in (data.get("expiryData") or [])][:4],
        "total_call_oi": call_oi, "total_put_oi": put_oi,
        "pcr_oi": round(put_oi / call_oi, 3) if call_oi else None,
        "day_call_oi_change": sum(float(c.get("oich") or 0) for c in calls),
        "day_put_oi_change": sum(float(c.get("oich") or 0) for c in puts),
        "call_volume": sum(float(c.get("volume") or 0) for c in calls),
        "put_volume": sum(float(c.get("volume") or 0) for c in puts),
        "top_call_oi_strikes": top(calls), "top_put_oi_strikes": top(puts),
        "levels": derive_levels(calls, puts, (under or {}).get("ltp")),
        "note": "Chain covers nearest expiry and strikes around spot only.",
    }


def get_option_chain(symbol: str, strikecount: int = 10, as_of: str | None = None) -> dict[str, Any]:
    """FYERS option-chain summary (OI, OI change, PCR, volume, top strikes) + weekly/monthly OI change from saved snapshots.
    Returns status=unavailable for stocks without listed options."""
    src = "fyers_option_chain"
    try:
        s = get_settings()
        t = parse_as_of(as_of)
        if t.date() < now_ist().date():
            return unavailable(src, "historical option chains are not available (live snapshot only)")
        sym = clean_symbol(symbol)
        day = now_ist().date().isoformat()

        # Require configured credentials before returning either cached or fresh data.
        # This keeps the tool's contract deterministic when credentials are absent.
        if not (s.fyers_app_id and s.fyers_access_token):
            return unavailable(src, "FYERS credentials not set")

        if refreshed_today("option_chain", sym) and (cached := kv_get("option_chain", f"{sym}|{day}")):
            return ok(src, cached["summary"], symbol=sym, cache="hit", captured_at=cached["captured_at"],
                      note="Cached from the first load today (refresh-once-a-day rule); use --force-refresh for a live re-pull.")
        _throttle()
        fy = _fyers_client()
        payload = fy.optionchain(data={"symbol": fyers_symbol(symbol), "strikecount": strikecount, "timestamp": "", "greeks": "1"}) or {}
        if payload.get("s") != "ok":
            return error(src, f"FYERS option chain {sym}: {payload.get('message') or payload.get('code') or payload}. "
                              "FYERS is the only source (no fallback); check the token with: python -m scripts.fyers_login")
        summary = summarize_chain(payload, t)
        summary["windows"] = _window_changes(symbol, summary["total_call_oi"], summary["total_put_oi"], t)
        stamp = now_ist().isoformat(timespec="seconds")
        lv = summary["levels"]
        _save_snapshot(symbol, {"captured_at": stamp, "call_oi": summary["total_call_oi"], "put_oi": summary["total_put_oi"],
                                "pcr": summary["pcr_oi"], "ltp": summary["underlying_ltp"], "support": lv["support"],
                                "resistance": lv["resistance"], "max_pain": lv["max_pain_approx"]})
        kv_set("option_chain", f"{sym}|{day}", {"summary": summary, "captured_at": stamp})
        mark_refreshed("option_chain", sym)
        return ok(src, summary, symbol=sym, cache="refreshed", captured_at=stamp)
    except Exception as exc:  # noqa: BLE001
        return error(src, exc)
